﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Infrastructure.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Ndihmo.Interfaces;
using Ndihmo.ViewModels;
using Pharmacy.Models;
using X.PagedList;

namespace Ndihmo.Repository
{
    public class RolesRepository:IRolesRepository
    {
        private readonly ApplicationDbContext _dbContext;

        public RolesRepository(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<ServiceResponse<string>> AddRole(IdentityRole role)
        {
            ServiceResponse<string> response = new();
            try
            {
               await _dbContext.Roles.AddAsync(role);
               await _dbContext.SaveChangesAsync();
            }
            catch (Exception e)
            {
                response.Message = e.Message;
                response.Success = false;
                return response;
            }

            return response;
        }

        public async Task<ServiceResponse<string>> UpdateRole(IdentityRole role)
        {
            ServiceResponse<string> response = new();
            try
            {
                var oldRole = await _dbContext.Roles.FirstOrDefaultAsync(x => x.Id == role.Id);
                oldRole.Name = role.Name;
                await _dbContext.SaveChangesAsync();
            }
            catch (Exception e)
            {
                response.Message = e.Message;
                response.Success = false;
                return response;
            }

            return response;
            
        }

        public async Task<ServiceResponse<string>> DeleteRole(string id)
        {
            ServiceResponse<string> response = new();
            try
            {
                var oldRole = await _dbContext.Roles.FirstOrDefaultAsync(x => x.Id == id);
                if (oldRole == null)
                {
                    response.Message = "Role Not Found";
                    response.Success = false;
                    return response;
                }

                _dbContext.Remove(oldRole);
                await _dbContext.SaveChangesAsync();
            }
            catch (Exception e)
            {
                response.Message = e.Message;
                response.Success = false;
                return response;
            }

            return response;
            
        }

        public async Task<ServiceResponse<string>> CreateRole(IdentityRole role)
        {
            ServiceResponse<string> response = new();
            try
            {
               await _dbContext.Roles.AddAsync(role);
               await _dbContext.SaveChangesAsync();
            }
            catch (Exception e)
            {
                response.Message = e.Message;
                response.Success = false;
                return response;
            }

            return response;
        }

        public async Task<ServiceResponse<IPagedList<IdentityRole>>> GetAllRoles(AllRolesViewModel model)
        {
            ServiceResponse<IPagedList<IdentityRole>> response = new();
            try
            {
                IQueryable<IdentityRole> query= _dbContext.Roles;
                query = GenerateQuery(query, model);
                response.Data = await query.ToPagedListAsync(model.Page,3);
            }
            catch (Exception e)
            {
                response.Message = e.Message;
                response.Success = false;
                return response;
            }
            return response;
        }

        public async Task<ServiceResponse<List<IdentityRole>>> GetAllRoles()
        {
            ServiceResponse<List<IdentityRole>> response = new();
            try
            {
                response.Data = await _dbContext.Roles.AsNoTracking().ToListAsync();
            }
            catch (Exception e)
            {
                response.Message = e.Message;
                response.Success = false;
                return response;
            }
            return response;
        }

        private IQueryable<IdentityRole> GenerateQuery(IQueryable<IdentityRole> query, AllRolesViewModel model)
        {
            if (model.OrderByDesc)
            {
                query=  query.OrderByDescending(x => x.Name);
            }
            if (model.OrderByAsc)
            {
                query= query.OrderBy(x=>x.Name);
            }

            if (!string.IsNullOrWhiteSpace(model.FilterString))
            {
                query = query.Where(x => x.Name.Contains(model.FilterString));
            }
            
            return query;
        }

        public async Task<ServiceResponse<IdentityRole>> GetOneRole(string id)
        {
            ServiceResponse<IdentityRole> response = new();
            try
            {
                response.Data = await _dbContext.Roles.FirstOrDefaultAsync(x => x.Id == id);
            }
            catch (Exception e)
            {
                response.Message = e.Message;
                response.Success = false;
                return response;
            }

            return response;
        }
    }
}