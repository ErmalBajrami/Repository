﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Infrastructure.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Ndihmo.DataModels;
using Ndihmo.Interfaces;
using Ndihmo.ViewModels;
using Pharmacy.Models;
using X.PagedList;

namespace Ndihmo.Repository
{
    public class UserRepository :IUserRepository
    {
        private readonly ApplicationDbContext _dbContext;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;

        public UserRepository(ApplicationDbContext dbContext,UserManager<ApplicationUser> userManager,RoleManager<IdentityRole> roleManager)
        {
            _dbContext = dbContext;
            _userManager = userManager;
            _roleManager = roleManager;
        }
        public async Task<ServiceResponse<string>> BanUser(string id)
        {
            ServiceResponse<string> response = new();
            try
            {
                var user = await _dbContext.ApplicationUsers.FirstOrDefaultAsync(x => x.Id == id);
                user.LockoutEnabled = !user.LockoutEnabled;
                _dbContext.Update(user);
               await _dbContext.SaveChangesAsync();

            }
            catch (Exception e)
            {
                response.Message = e.Message;
                response.Success = false;
            }

            return response;
        }

        public async Task<ServiceResponse<IPagedList<ApplicationUser>>> GetAllUsers(AllUsersViewModel inputModel)
        {
            ServiceResponse<IPagedList<ApplicationUser>> response = new();
            try
            {
                IQueryable<ApplicationUser> query = _dbContext.ApplicationUsers;
                query = GenerateQueryFromFilters(query, inputModel);
                response.Data = await query.Include(x=>x.City).ToPagedListAsync(inputModel.Page, 1);
            }
            catch (Exception e)
            {
                response.Message = e.Message;
                response.Success = false;
            }
            return response;
            
        }

        private IQueryable<ApplicationUser> GenerateQueryFromFilters(IQueryable<ApplicationUser> query,AllUsersViewModel inputModel)
        {
            if (!string.IsNullOrWhiteSpace(inputModel.FilterString))
            {
                query = query.Where(x =>
                    x.Email.Contains(inputModel.FilterString) || x.UserName.Contains(inputModel.FilterString));
            }
            if (!string.IsNullOrWhiteSpace(inputModel.CityId))
            {
                query = query.Where(x => x.CityId == inputModel.CityId);
            }
            switch (inputModel.OrderBy)
            {
                case "Email":
                    query = inputModel.OrderByDes ? query.OrderByDescending(x => x.Email) : query.OrderBy(x => x.Email);
                    break;
                case "Username":
                    query = inputModel.OrderByDes ? query.OrderByDescending(x => x.Email) : query.OrderBy(x => x.UserName);
                    break;
                case "City":
                    query = inputModel.OrderByDes ? query.OrderByDescending(x => x.Email) : query.OrderBy(x => x.City);
                    break;
            }
           
            return query;
        }
      
        public async Task<ServiceResponse<ApplicationUser>> GetOneUser(string id)
        {
            ServiceResponse<ApplicationUser> response = new();
            try
            {
                response.Data = await _dbContext.ApplicationUsers.Include(x=>x.City).Include(x=>x.Campaigns).ThenInclude(x=>x.Donations).AsNoTracking().FirstOrDefaultAsync(x => x.Id == id);

            }
            catch (Exception e)
            {
                response.Message = e.Message;
                response.Success = false;
            }

            return response;        }

        public async Task<ServiceResponse<List<City>>> AllCities()
        {
            ServiceResponse<List<City>> response = new();
            try
            {
                response.Data = await _dbContext.City.ToListAsync();

            }
            catch (Exception e)
            {
                response.Message = e.Message;
                response.Success = false;
            }

            return response;       
        }

        public async Task<ServiceResponse<List<IdentityRole>>> GetRolesForUser(string id)
        {
            ServiceResponse<List<IdentityRole>> response = new();
            try
            {
                var roles = await _dbContext.Roles
                    .Where(x => 
                        _dbContext.UserRoles.Where(x=>x.UserId==id).Select(x => x.RoleId).Contains(x.Id))
                    .AsNoTracking().ToListAsync();
                response.Data = roles;
            }
            catch (Exception e)
            {
                response.Message = e.Message;
                response.Success = false;
            }
            return response;
        }

        public async Task<ServiceResponse<string>> UpdateRolesForUser(string userId, List<IdentityRole> roles)
        {
            ServiceResponse<string> response = new();
            try
            {
                var allRoles = await _dbContext.UserRoles.Where(x => x.UserId == userId).ToListAsync();
                _dbContext.RemoveRange(allRoles);
                var newRoles = new List<IdentityUserRole<string>>();
                foreach (var identityRole in roles)
                {
                    newRoles.Add(new IdentityUserRole<string>(){UserId =userId, RoleId = identityRole.Id});
                }
                await _dbContext.UserRoles.AddRangeAsync(newRoles);
               await _dbContext.SaveChangesAsync();

            }
            catch (Exception e)
            {
                response.Message = e.Message;
                response.Success = false;
            }
            return response;
        }
    }
}