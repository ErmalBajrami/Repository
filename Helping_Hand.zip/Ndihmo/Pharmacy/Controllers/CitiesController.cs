﻿using Infrastructure.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Ndihmo.DataModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Ndihmo.TagHelpers;
using Ndihmo.ViewModels;
using X.PagedList;
using Microsoft.Extensions.Logging;

namespace Ndihmo.Controllers
{
    [Authorize(Roles = "Admin")]
    public class CitiesController : Controller
    {
        private readonly ApplicationDbContext _dbContext;
        private readonly ILogger<City> _logger;

        // GET: CitiesController
        public CitiesController(ApplicationDbContext dbContext,ILogger<City> logger)
        {
            _dbContext = dbContext;
            _logger = logger;
        }
        public async Task<IActionResult> Index(int pg,string SearchText, bool orderByDesc)
        {
            const int pageSize = 3;
            if (pg < 1)
            {
                pg = 1;
            }
            int recsCount = await _dbContext.City.CountAsync();
            var pager = new CitiesPaging(recsCount, pg, pageSize);
            int recSkip = (pg - 1) * pageSize;
            var query =  _dbContext.City.Skip(recSkip).Take(pager.PageSize).AsQueryable();
            if (!string.IsNullOrWhiteSpace(SearchText))
            {
                query = query.Where(x => x.Name.Contains(SearchText));
            }
             var data = await query.ToListAsync();
            this.ViewBag.CitiesPaging = pager;
            query = GenerateQueryFromFilters(query, orderByDesc);

            //order by\
            AllCitiesViewModel model = new AllCitiesViewModel()
            {
                OrderByCity = orderByDesc 
            };

            model.AllCities = query.ToList();
            _logger.LogInformation($"{model.AllCities.Count()} citys fetched");
            //return View(cities);
            return View(model);
        }

        private static IQueryable<City> GenerateQueryFromFilters(IQueryable<City> query, bool orderByDesc)
        {
            if (orderByDesc)
            {
                query = query.OrderByDescending(x => x.Name);
            }
            else {
                query = query.OrderBy(x => x.Name);
            }

            return query;

        }


        // GET: CitiesController/Details/5
        public ActionResult Details(string id)
        {
            var city = _dbContext.City.FirstOrDefault(x => x.Id == id);
            return View(city);
        }

        // GET: CitiesController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: CitiesController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(City newCity)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _dbContext.City.Add(newCity);
                    _dbContext.SaveChanges();
                    _logger.LogInformation($"{newCity.Id} city created");
                    return RedirectToAction(nameof(Index));
                }
                return View();
            }
            catch
            {
                return View();
            }
        }

        // GET: CitiesController/Edit/5
        public ActionResult Edit(string id)
        {
            var city = _dbContext.City.FirstOrDefault(x => x.Id == id);
            return View(city);
        }

        // POST: CitiesController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(string id, City updatedCity)
        {
            try
            {
                if (ModelState.IsValid)
                {

                    var oldCity = _dbContext.City.FirstOrDefault(x => x.Id == id);
                    oldCity.Name = updatedCity.Name;
                    _dbContext.SaveChanges();
                    _logger.LogInformation($"{id} city updated");
                    return RedirectToAction(nameof(Index));
                }
                return View();
            
            }
            catch
            {
                return View();
            }
        }

        // GET: CitiesController/Delete/5
        public ActionResult Delete(string id)
        {
            var city = _dbContext.City.FirstOrDefault(x => x.Id == id);
            return View(city);
        }

        // POST: CitiesController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteCity(string id)
        {
            try
            {
                var city = _dbContext.City.FirstOrDefault(x => x.Id == id);
                _dbContext.Remove(city);
                _dbContext.SaveChanges();
                _logger.LogInformation($"{id} city deketed");
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
