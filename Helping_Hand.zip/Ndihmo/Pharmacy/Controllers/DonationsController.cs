﻿using Infrastructure.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Ndihmo.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Ndihmo.Controllers
{
    [Authorize]
    public class DonationsController : Controller
    {
        private readonly ApplicationDbContext _db;
        private readonly ILogger<Donation> _logger;

        public DonationsController(ApplicationDbContext db,ILogger<Donation> logger )
        {
            _db = db;
            _logger = logger;
        }
        // GET: DonationsController
        public ActionResult Index()
        {
            return View();
        }

        // GET: DonationsController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: DonationsController/Create
        public ActionResult Create(string id)
        {
            if (string.IsNullOrWhiteSpace(id))
            {
                return NotFound();
            }
            if (!_db.Campaigns.Any(s => s.Id == id))
            {
                return NotFound();
            }
            ViewBag.CampId = id;
            return View();
        }

        // POST: DonationsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Donation don)
        {
            don.UserId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (!ModelState.IsValid)
            {
                return View(don);
            }
            try
            {
                _db.Donations.Add(don);
                _db.SaveChanges();
                _logger.LogInformation($"{don.Id} donation made");
            }
            catch
            {
                return View();
            }
            return RedirectToAction("Details", "Campaigns", new { id = don.CampaignId });
        }

        // GET: DonationsController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: DonationsController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: DonationsController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: DonationsController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
