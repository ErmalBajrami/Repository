﻿
using Infrastructure.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Ndihmo.DataModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Ndihmo.TagHelpers;
using Ndihmo.ViewModels;
using X.PagedList;
using Microsoft.Extensions.Logging;

namespace Ndihmo.Controllers
{
    [Authorize]
    public class CampaignsController : Controller
    {
        private readonly ApplicationDbContext _dbContext;
        private readonly ILogger<Campaign> _logger;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public CampaignsController(ApplicationDbContext dbContext,ILogger<Campaign> logger,IWebHostEnvironment webHostEnvironment)
        {
            _dbContext = dbContext;
            _logger = logger;
            _webHostEnvironment = webHostEnvironment;
        }

        // GET: BlogController
        public ActionResult Index(int page,string searchString, bool orderByDes, string orderBy,string city)
        {
            AllCampaignsViewModel model = new AllCampaignsViewModel()
            {
                FilterString = searchString,
                CityId = city,
                Page = page,
                OrderByDes = orderByDes,
                OrderBy = orderBy
            };
            
            var userId = HttpContext.User.GetUserId();
            var listCampaign = _dbContext.Campaigns.AsQueryable();
            listCampaign = GenerateQueryFromFilters(listCampaign, orderByDes, orderBy,searchString, city);
            var results = listCampaign.Include(x => x.City).Include(x => x.Category).Where(x => x.UserId == userId)
                .ToPagedList(model.Page, 50);
            model.AllCampaigns = results;
            model.Cities = _dbContext.City.Select(x => new SelectListItem() { Text = x.Name, Value = x.Id }).ToList();
            _logger.LogInformation($"{model.AllCampaigns.Count()} campaigns fetched ");
            return View(model);
        }

        private IQueryable<Campaign> GenerateQueryFromFilters(IQueryable<Campaign> query, bool orderByDesc,
            string orderBy,string filterWord,string city)
        {
            switch (orderBy)
            {
                case "startDate":
                    query = orderByDesc ? query.OrderByDescending(x => x.StartDate) : query.OrderBy(x => x.StartDate);
                    break;
                case "title":
                    query = orderByDesc ? query.OrderByDescending(x => x.Title) : query.OrderBy(x => x.Title);
                    break;
                case "city":
                    query = orderByDesc ? query.OrderByDescending(x => x.City.Name) : query.OrderBy(x => x.City.Name);
                    break;
                case "category":
                    query = orderByDesc ? query.OrderByDescending(x => x.Category.CategoryName) : query.OrderBy(x => x.Category);
                    break;
                case "goal":
                    query = orderByDesc
                        ? query.OrderByDescending(x => x.CampaignGoal)
                        : query.OrderBy(x => x.CampaignGoal);
                    break;
                default:
                    query = orderByDesc ? query.OrderByDescending(x => x.StartDate) : query.OrderBy(x => x.StartDate);
                    break;
                   
            }
            if (!string.IsNullOrWhiteSpace(filterWord))
            {
                query = query.Where(x => x.Title.Contains(filterWord));
            }
            if (!string.IsNullOrWhiteSpace(city))
            {
                query = query.Where(x => x.CityId == city);
            }
            return query;
        }
        [AllowAnonymous]
        public ActionResult Details(string id)
        {
            var campaign = _dbContext.Campaigns.Include(x=>x.Donations).ThenInclude(x=>x.User).Include(x=>x.User)
                .Include(x=>x.Category).Include(x=>x.City).FirstOrDefault(x => x.Id == id);
            return View(campaign);
        }

        // GET: BlogController/Create
        public ActionResult Create()
        {
            CampaignsViewModel model = new CampaignsViewModel();
            model.Cities = _dbContext.City.Select(x => new SelectListItem() { Text = x.Name, Value = x.Id }).ToList();
            model.CampaignCategory = _dbContext.Categories
                .Select(x => new SelectListItem() { Text = x.CategoryName, Value = x.Id }).ToList();

            return View(model);
        }

        // POST: BlogController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(CampaignsViewModel newCampaign)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return View(newCampaign);
                }

                if (newCampaign.FormFile != null)
                {
                    newCampaign.Campaign.ImagePath = SaveImage(newCampaign.FormFile);
                }
                
                newCampaign.Campaign.StartDate = DateTime.UtcNow;
                newCampaign.Campaign.UserId = HttpContext.User.GetUserId();
                if (ModelState.IsValid)
                {
                    _dbContext.Campaigns.Add(newCampaign.Campaign);
                    _dbContext.SaveChanges();
                    _logger.LogInformation($"{newCampaign.Campaign.Id} campaign created");
                    return RedirectToAction(nameof(Index));
                }

                return View();
            }
            catch
            {
                return View(newCampaign);
            }
        }

        private string SaveImage(IFormFile formFile)
        {
            var extension=  Path.GetExtension(formFile.FileName);
            string filename= $"{Guid.NewGuid().ToString()}.{extension}";
            string savePath =    Path.Combine(_webHostEnvironment.WebRootPath, "CampaignImages",filename);
            using (var fileStream = new FileStream(savePath,FileMode.CreateNew))
            {
                formFile.CopyTo(fileStream);
            }

            return filename;
        }
        // GET: BlogController/Edit/5
        public ActionResult Edit(string id)
        {
            CampaignsViewModel model = new CampaignsViewModel();
            model.Campaign = _dbContext.Campaigns.FirstOrDefault(x => x.Id == id);
            model.Cities = _dbContext.City.Select(x => new SelectListItem() { Text = x.Name, Value = x.Id }).ToList();
            model.CampaignCategory = _dbContext.Categories
                .Select(x => new SelectListItem() { Text = x.CategoryName, Value = x.Id }).ToList();
            
            return View(model);
        }

        public ActionResult EditPic(CampaignsViewModel model)
        {
            try
            {
                string imagePath = null;
                if (model.FormFile != null)
                {
                    imagePath = SaveImage(model.FormFile);
                }

                var capaign= _dbContext.Campaigns.FirstOrDefault(x => x.Id == model.Campaign.Id);
                capaign.ImagePath = imagePath;
                _dbContext.Update(capaign);
                _dbContext.SaveChanges();
            }
            catch (Exception e)
            {
                return RedirectToAction(nameof(Index));
            }
          
          return RedirectToAction(nameof(Index));
        }
        // POST: BlogController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(string id,  CampaignsViewModel updatedCampaign)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var oldCampaign = _dbContext.Campaigns.FirstOrDefault(x => x.Id == id);
                    oldCampaign.Title = updatedCampaign.Campaign.Title;
                    oldCampaign.Description = updatedCampaign.Campaign.Description;
                    oldCampaign.CategoryId = updatedCampaign.Campaign.CategoryId;
                    oldCampaign.CityId = updatedCampaign.Campaign.CityId;
                    oldCampaign.CampaignGoal = updatedCampaign.Campaign.CampaignGoal;
                    _dbContext.SaveChanges();
                    return RedirectToAction(nameof(Index));
                }
                _logger.LogInformation($"{id} campaign updated");
                return View(updatedCampaign);
            }
            catch(Exception e)
            {
                _logger.LogError(e.Message);
                return View(updatedCampaign);
            }
        }

        // GET: BlogController/Delete/5
        public ActionResult Delete(string id)
        {
            var campaign = _dbContext.Campaigns.FirstOrDefault(x => x.Id == id);
            return View(campaign);
        }

        // POST: BlogController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteCampaign(string id)
        {
            try
            {
                var campaign = _dbContext.Campaigns.FirstOrDefault(x => x.Id == id);
                _dbContext.Remove(campaign);
                _dbContext.SaveChanges();
                return RedirectToAction(nameof(Index));
                _logger.LogInformation($"{id} campaign deleted");
            }
            catch(Exception e)
            {
                _logger.LogError(e.Message);
                return RedirectToAction(nameof(Index));
            }
        }
    }
}