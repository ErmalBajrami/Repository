﻿using Infrastructure.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Ndihmo.DataModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Ndihmo.TagHelpers;
using Ndihmo.ViewModels;
using X.PagedList;
using Microsoft.Extensions.Logging;

namespace Ndihmo.Controllers
{
    [Authorize(Roles ="Admin")]
    public class CategoriesController : Controller
    {
        private readonly ApplicationDbContext _dbContext;
        private readonly ILogger<Category> _logger;

        public CategoriesController(ApplicationDbContext dbContext,ILogger<Category> logger)
        {
            _dbContext = dbContext;
            _logger = logger;
        }
        //Get: CategoriesController
        public async Task<IActionResult> Index(int pg, string SearchText, bool orderByDesc)
        {
            const int pageSize = 3;
            if (pg < 1)
            {
                pg = 1;
            }
            int recsCount = await _dbContext.Categories.CountAsync();
            var pager = new CitiesPaging(recsCount, pg, pageSize);
            int recSkip = (pg - 1) * pageSize;
            var query = _dbContext.Categories.Skip(recSkip).Take(pager.PageSize).AsQueryable();
            if (!string.IsNullOrWhiteSpace(SearchText))
            {
                query = query.Where(x => x.CategoryName.Contains(SearchText));
            }
            
            this.ViewBag.CitiesPaging = pager;
            query = GenerateQueryFromFilters(query, orderByDesc);

            //order by\
            AllCategoriesViewModel model = new AllCategoriesViewModel()
            {
                OrderByCategory = orderByDesc
            };

            model.AllCategories = query.ToList();
            //return View(cities);
            _logger.LogInformation($"{model.AllCategories.Count()} categories fetched");
            return View(model);
        }
        private static IQueryable<Category> GenerateQueryFromFilters(IQueryable<Category> query, bool orderByDesc)
        {
            if (orderByDesc)
            {
                query = query.OrderByDescending(x => x.CategoryName);
            }
            else
            {
                query = query.OrderBy(x => x.CategoryName);
            }

            return query;

        }

        //Get: CategoriesController/Create
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Category newCategory)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _dbContext.Categories.Add(newCategory);
                    _dbContext.SaveChanges();
                    _logger.LogInformation($"{newCategory.Id} categorie created");
                    return RedirectToAction(nameof(Index));
                }
                return View();
            }
            catch
            {
                return View();
            }
        }

        // Get: CategoriesController/edit

        public ActionResult Edit(string id)
        {
            var category = _dbContext.Categories.FirstOrDefault(x => x.Id == id);
            return View(category);
        }

        //Post: CategoriesController/Edit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(string id, Category updatedCategory)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var oldCategory = _dbContext.Categories.FirstOrDefault(x => x.Id == id);
                    oldCategory.CategoryName = updatedCategory.CategoryName;
                    oldCategory.Campaigns = updatedCategory.Campaigns;
                    _dbContext.SaveChanges();
                    _logger.LogInformation($"{id} categorie updated");
                    return RedirectToAction(nameof(Index));
                }
                return View();

            }
            catch
            {
                return View();
            }
        }

        //Get : CategoriesController/Delete

        public ActionResult Delete(string id)
        {
            var category = _dbContext.Categories.FirstOrDefault(x => x.Id == id);
            return View(category);
        }


        //Post : CategoriesController/Delete
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteCategory(string id)
        {
            try
            {
                var category = _dbContext.Categories.FirstOrDefault(x => x.Id == id);
                _dbContext.Remove(category);
                _dbContext.SaveChanges();
                _logger.LogInformation($"{id} categorie deleted");
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return RedirectToAction(nameof(Index));
            }
        }

    }
}
