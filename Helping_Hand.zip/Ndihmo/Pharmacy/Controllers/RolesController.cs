﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Ndihmo.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.VisualStudio.Web.CodeGeneration.Contracts.Messaging;
using Ndihmo.ViewModels;
using Microsoft.Extensions.Logging;

namespace Ndihmo.Controllers
{
    [Authorize(Roles = "Admin")]
    public class RolesController : Controller
    {
        private readonly IRolesRepository _repository;
        private readonly ILogger<IdentityRole> _logger;

        public RolesController(IRolesRepository repository,ILogger<IdentityRole> logger  )
        {
            _repository = repository;
            _logger = logger;
        }

        // GET: RolesController
        public async Task<IActionResult> Index(int page,bool orderByDesc,bool orderByAsc,string searchString)
        {
            AllRolesViewModel model = new() { Page = page, OrderByDesc = orderByDesc,OrderByAsc = orderByAsc,FilterString = searchString};
            var response = await _repository.GetAllRoles(model);
            model.AllRoles = response.Data;
            _logger.LogInformation($"{response.Data.Count()} roles fetched");
            return View(model);
        }

        // GET: RolesController/Details/5
        /*public IActionResult Details(int id)
        {
            return View();
        }*/

        // GET: RolesController/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: RolesController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(IdentityRole role)
        {
            if (!ModelState.IsValid) 
            {
                return View(role);
            }

            (string message, bool success)=ValidateRoleInput(role);
            if (!success)
            {
                ModelState.AddModelError(string.Empty,message);
                return View(role);
            }
            var response =await _repository.AddRole(role);
            if (!response.Success) 
            {
                ModelState.AddModelError(string.Empty, response.Message);
                return View(role);
            }
            _logger.LogInformation($"{role.Id} role created");
            return RedirectToAction("Index");
          
        }

        private (string message, bool success) ValidateRoleInput(IdentityRole role)
        {
            if (string.IsNullOrWhiteSpace(role.Name))
            {
                return ("Role Name Can Not Be Empty", false);
            }

            return ("", true);
        }
        // GET: RolesController/Edit/5
        public async Task<IActionResult> Edit(string id)
        {
            var response = await _repository.GetOneRole(id);
            var role = response.Data;
            return View(role);
        }

        // POST: RolesController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(IdentityRole role)
        {
            if (!ModelState.IsValid)
            {
                return View(role);
            }

            var validResponse = ValidateRoleInput(role);
            if (!validResponse.success)
            {
                ModelState.AddModelError(string.Empty,validResponse.message);
                return View(role);
            }
            var response = await _repository.UpdateRole(role);
            if (!response.Success)
            {
                ModelState.AddModelError(string.Empty, response.Message);
                return View(role);
            }
            _logger.LogInformation($"{role.Id} roles updated");
            return RedirectToAction("Index");
        }
        [HttpGet]
        // GET: RolesController/Delete/5
        public async Task<IActionResult> Delete(string id)
        {
            var response = await _repository.GetOneRole(id);
            var role = response.Data;
            return View(role);
        }

        // POST: RolesController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteRole(string id)
        {
            var response = await _repository.DeleteRole(id); _logger.LogInformation($"{id} roles deleted");

            return RedirectToAction("Index");
        }
    }
}
