﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Pharmacy.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using Ndihmo.ViewModels;
using Ndihmo.DataModels;

namespace Pharmacy.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationDbContext _dbContext;

        public HomeController(ILogger<HomeController> logger,ApplicationDbContext dbContext)
        {
            _logger = logger;
            _dbContext = dbContext;
        }

        public IActionResult Index()
        {
            HomePageModelViewModel model = new();
            model.Campaigns = _dbContext.Campaigns.OrderBy(x=>x.StartDate).Take(10).Include(x=>x.Donations).AsNoTracking().ToList();
            return View(model);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult Dashboard()
        {
            return View();
        }
        public async Task<IActionResult> AllCampaigns(string orderBy,string categorie, string searchString)
        {
            
            AllCampaignsViewModel model = new();
            model.OrderBy = orderBy;
            model.Categorie = categorie;
            model.SearchString = searchString;
            model.Categories = _dbContext.Categories.Select(x => new Microsoft.AspNetCore.Mvc.Rendering.SelectListItem() {Text=x.CategoryName,Value=x.Id }).ToList();
            var selcategorie = model.Categories.FirstOrDefault(x => x.Value == model.Categorie);
            if (selcategorie!=null)
            {
                selcategorie.Selected = true;
            }
            var query = _dbContext.Campaigns.AsQueryable();
            query = GenerateQueryForAllCamp(query, orderBy,categorie,searchString);
            model.Campaigns = query.Include(x=>x.Donations).ToList();
            return View(model);
        }
        private IQueryable<Campaign> GenerateQueryForAllCamp (IQueryable<Campaign> query, string orderBy,string categorie,string searchString)
        {
            switch (orderBy)
            {
                case "recent":
                    query = query.OrderBy(x=>x.StartDate);
                    break;
                case "Oldest":
                    query =query.OrderByDescending(x=>x.StartDate);
                    break;
                case "fgoal":
                    query = query.OrderBy(x=>x.CampaignGoal-x.Donations.Sum(x=>x.DonationSum));
                    break;
                case "cgoal":
                    query = query.OrderByDescending(x => x.CampaignGoal - x.Donations.Sum(x => x.DonationSum));
                    break;
                default:
                   query = query.OrderBy(x => x.StartDate); ;
                    break;
            }
            if (!string.IsNullOrWhiteSpace(searchString))
            {
                query = query.Where(x => x.Title.Contains(searchString));
            }
            if (!string.IsNullOrWhiteSpace(categorie)&& !categorie.ToLower().Equals("all"))
            {
                query = query.Where(x => x.CategoryId == categorie);
            }
            return query;
        }
    }
}
