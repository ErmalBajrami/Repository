﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Ndihmo.Interfaces;
using Ndihmo.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Logging;
using Ndihmo.DataModels;

namespace Ndihmo.Controllers
{

    public class UsersController : Controller
    {
        private readonly IUserRepository _repository;
        private readonly IRolesRepository _rolesRepository;
        private readonly ILogger<ApplicationUser> _logger;

        // GET: UsersController
        public UsersController(IUserRepository repository,IRolesRepository rolesRepository,ILogger<ApplicationUser> logger)
        {
            _repository = repository;
            _rolesRepository = rolesRepository;
            _logger = logger;
        }
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Index(int page,string searchString,string city,bool orderByDes,string orderBy)
        {
            AllUsersViewModel model = new AllUsersViewModel(){Page = page,FilterString = searchString,CityId = city,OrderBy = orderBy,OrderByDes = orderByDes};
            var response = await _repository.GetAllUsers(model);
            var citiesResponse = await _repository.AllCities();
            model.Cities = citiesResponse.Data;
            model.AllUsers = response.Data;
            _logger.LogInformation($"{model.AllUsers.Count()} users fetched");
            return View(model);
        }

        // GET: UsersController/Details/5
        [Authorize(Roles = "User")]
        public async Task<IActionResult> Details(string id)
        {
            var response = await _repository.GetOneUser(id);
            return View(response.Data);
        }

        /*
        public IActionResult Edit(int id)
        {
            return View();
        }

        // POST: UsersController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }*/
        [Authorize(Roles = "Admin")]
        [HttpGet]
        public async Task<IActionResult> ManageRoles(string id)
        {
            UserRolesViewModel userRolesViewModel = new(){UserId = id};
           var roles= await _repository.GetRolesForUser(id);
           var allRoles = await _rolesRepository.GetAllRoles();
           userRolesViewModel.GenerateUserRoleDto(roles.Data,allRoles.Data);
           var userResponse = await _repository.GetOneUser(id);
           userRolesViewModel.User = userResponse.Data;
           return View(userRolesViewModel);
        }
        [Authorize(Roles = "Admin")]

        [HttpPost]
        public async Task<IActionResult> ManageRoles(UserRolesViewModel model)
        {
            var response = await _repository.UpdateRolesForUser(model.UserId, model.GetAllUserRolesFromDto());
            _logger.LogInformation($"{model.UserId} user roles updated");
            return RedirectToAction("Index");
        }
        [Authorize(Roles = "Admin")] 
        // GET: UsersController/Delete/5
        public async Task<IActionResult> BanUser(string id)
        {
            var model = await _repository.GetOneUser(id);
         

            return View(model.Data);
        }
        [Authorize(Roles = "Admin")]

        // POST: UsersController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> BanUserById(string id)
        {
            var response = await _repository.BanUser(id);
            _logger.LogInformation($"{id} user banned");
            return RedirectToAction("Index");
        }
    }
}
