﻿using Infrastructure.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Ndihmo.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Ndihmo.Controllers
{
    public class BlogController : Controller
    {
        private readonly ApplicationDbContext _dbContext;

        public BlogController(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }
        // GET: BlogController
        public ActionResult Index()
        {
            List<Blog> listBlog = _dbContext.Blog.ToList();
            return View(listBlog);
        }

        // GET: BlogController/Details/5
        public ActionResult Details(int id)
        {
            var blog = _dbContext.Blog.FirstOrDefault(x => x.Id == id);
            return View(blog);
        }

        // GET: BlogController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: BlogController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Blog newBlog)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _dbContext.Blog.Add(newBlog);
                    _dbContext.SaveChanges();

                    return RedirectToAction(nameof(Index));
                }
                return View();
            }
            catch
            {
                return View();
            }
        }

        // GET: BlogController/Edit/5
        public ActionResult Edit(int id)
        {
            var blog = _dbContext.Blog.FirstOrDefault(x => x.Id == id);
            return View(blog);
        }

        // POST: BlogController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Blog updatedBlog)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var oldBlog = _dbContext.Blog.FirstOrDefault(x => x.Id == id);
                    oldBlog.Title = updatedBlog.Title;
                    oldBlog.Content = updatedBlog.Content;
                    _dbContext.SaveChanges();
                    return RedirectToAction(nameof(Index));
                }
                return View();

            }
            catch
            {
                return View();
            }
        }

        // GET: BlogController/Delete/5
        public ActionResult Delete(int id)
        {
            var blog = _dbContext.Blog.FirstOrDefault(x => x.Id == id);
            return View(blog);
        }

        // POST: BlogController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteBlog(int id)
        {
            try
            {
                var blog = _dbContext.Blog.FirstOrDefault(x => x.Id == id);
                _dbContext.Remove(blog);
                _dbContext.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
