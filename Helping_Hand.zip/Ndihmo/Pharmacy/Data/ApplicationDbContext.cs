﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ndihmo.Data;
using Ndihmo.DataModels;

namespace Infrastructure.Data
{
   public  class ApplicationDbContext:IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options ):base(options)
        {

        }
        public DbSet<ApplicationUser> ApplicationUsers { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.SeedData();
        }
        public DbSet<Ndihmo.DataModels.City> City { get; set; }
        public DbSet<Ndihmo.DataModels.Blog> Blog { get; set; }
        public DbSet<Campaign> Campaigns { get; set; }
        public DbSet<ApproveRequest> Requests { get; set; }
        public DbSet<Category> Categories { get; set; }

        public DbSet<Donation> Donations { get; set; }

        public DbSet<Update> CampaignsUpdates { get; set; }

        

    }
}
