﻿using System;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Ndihmo.DataModels;

namespace Ndihmo.Data
{
    public static class DbContextSeedExtension
    {
        public static void SeedData(this ModelBuilder builder)
        {
            #region Users

            const string adminId = "a18be9c0-aa65-4af8-bd17-00bd9344e575";
            const string roleId = adminId;
            var hasher = new PasswordHasher<ApplicationUser>();

            builder.Entity<ApplicationUser>().HasData
            (
                new ApplicationUser
                {
                    Id = adminId,
                    Email = "Adminemail@gmail.com",
                    UserName = "Admin",
                    NormalizedUserName = "Admin".ToUpper(),
                    NormalizedEmail = "Adminemail@gmail.com".ToUpper(),
                    PasswordHash = hasher.HashPassword(null, "P@ssw0rd"),
                    FullName = "Admin",
                    CityId = "1",
                    EmailConfirmed=true
                }
            );
            ;

            #endregion
            #region Category

            builder.Entity<Category>().HasData( new 
                Category()
                {
                    Id = "1",
                    CategoryName = "Education"
                },
                new Category()
                {
                    Id = "2",
                    CategoryName = "Animal"
                },
                new Category()
                {
                    Id = "3",
                    CategoryName = "Emergency"
                });
            #endregion

            #region Campaigns

            builder.Entity<Campaign>().HasData
            (
                new Campaign()
                {
                    Id="1",
                    Title = "Support Tim For Semester 3 of Berklee",
                    Description = "Hello dear friends! Somehow, I've almost finished my second semester here at Berklee College of Music - where has this year gone?? It's been an incredible time so far. I've studied the complexities of jazz & classical harmony, developed my musical ear, performed in wonderful places with supremely talented musicians, written & collaborated on a bunch of new songs and even taken a fantastic psychology class (not forgetting the equally fantastic tap dance class, of course!). So in short, when I return to the UK I'll be diagnosing all your problems through song (featuring many modulations) all while tap dancing. Or something like that.",
                    StartDate = DateTime.UtcNow,
                    CampaignGoal = 15000,
                    UserId = adminId,
                    CategoryId = "1",
                    CityId ="1"
                }
            );

            #endregion

            #region Citys

            builder.Entity<City>().HasData
            (
                new City()
                {
                    Id = "1",
                    Name = "Ferizaj"
                },
                new City()
                {
                    Id = "2",
                    Name = "Prishtin"
                }
            );

            #endregion

            #region Roles

            builder.Entity<IdentityRole>().HasData
            (
                new IdentityRole
                {
                    Name = "Admin",
                    Id = roleId,
                    NormalizedName = "ADMIN"
                }
            );
            builder.Entity<IdentityRole>().HasData
            (
                new IdentityRole
                {
                    Name = "User",
                    Id = "2",
                    NormalizedName = "USER"
                }
            );
            #endregion

            #region UserRoles

            builder.Entity<IdentityUserRole<string>>().HasData
            (
                new IdentityUserRole<string>
                {
                    RoleId = roleId,
                    UserId = adminId
                }
            );

            #endregion
        }
    }
}