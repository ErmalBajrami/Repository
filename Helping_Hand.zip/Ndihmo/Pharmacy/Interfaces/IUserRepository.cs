﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Ndihmo.DataModels;
using Ndihmo.ViewModels;
using Pharmacy.Models;
using X.PagedList;

namespace Ndihmo.Interfaces
{
    public interface IUserRepository
    {
        Task<ServiceResponse<string>> BanUser(string id);
        Task<ServiceResponse<IPagedList<ApplicationUser>>> GetAllUsers(AllUsersViewModel inputModel);
        Task<ServiceResponse<ApplicationUser>> GetOneUser(string id);
        Task<ServiceResponse<List<City>>> AllCities();
        Task<ServiceResponse<List<IdentityRole>>> GetRolesForUser(string id);
        
        Task<ServiceResponse<string>> UpdateRolesForUser(string userId, List<IdentityRole> roles);



    }
}