﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Ndihmo.ViewModels;
using Pharmacy.Models;
using X.PagedList;

namespace Ndihmo.Interfaces
{
    public interface IRolesRepository
    {
        Task<ServiceResponse<string>> AddRole(IdentityRole role);
        Task<ServiceResponse<string>> UpdateRole(IdentityRole role);
        Task<ServiceResponse<string>> DeleteRole(string id);
        Task<ServiceResponse<string>> CreateRole(IdentityRole role);
        Task<ServiceResponse<IPagedList<IdentityRole>>> GetAllRoles(AllRolesViewModel model);
        Task<ServiceResponse<List<IdentityRole>>> GetAllRoles();
        Task<ServiceResponse<IdentityRole>> GetOneRole(string id);
    }
}