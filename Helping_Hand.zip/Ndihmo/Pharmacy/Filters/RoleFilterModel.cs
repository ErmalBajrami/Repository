﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Identity;
using X.PagedList;

namespace Ndihmo.Filters
{
    public class RoleFilterModel
    {
        public IPagedList<IdentityRole> AllRoles { get; set; }
        public bool OrderByDesc { get; set; }
        public int Page
        {
            get => Page;
            set
            {
                if (value==0)
                {
                    value = 1;
                }
            }
        }
    }
}