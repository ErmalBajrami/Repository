﻿namespace Ndihmo.DataModels
{
    public class Donation:BaseModels
    {
        public double DonationSum { get; set; }
        public string DonationMessage { get; set; }
        public string UserId { get; set; }
        public virtual ApplicationUser User { get; set; }
        public string CampaignId { get; set; }
        public virtual Campaign Campaign { get; set; }
    }
}