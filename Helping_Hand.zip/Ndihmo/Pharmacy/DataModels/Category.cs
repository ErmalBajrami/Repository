﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace Ndihmo.DataModels
{
    public class Category:BaseModels
    {
        public string CategoryName { get; set; }
        public virtual List<Campaign> Campaigns { get; set; }
        public string Name { get; set; }
    }
}