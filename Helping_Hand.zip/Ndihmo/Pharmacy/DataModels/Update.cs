﻿using System;

namespace Ndihmo.DataModels
{
    public class Update:BaseModels
    {
        public string CampaignId { get; set; }
        public virtual Campaign Campaign { get; set; }
        public string UpdateImage { get; set; }
        public DateTime UpdateDate { get; set; }
        public string UpdateMessage { get; set; }


    }
}
