﻿using System;

namespace Ndihmo.DataModels
{
    public class ApproveRequest :BaseModels
    {
       
        public string CampaignId { get; set; }
        public virtual Campaign Campaign { get; set; }
        public DateTime RequestDate{ get; set; }
        public string ConfirmedByUserId { get; set; }
        public ApplicationUser ConfirmedByUser { get; set; }
        public string RequestMessage { get; set; }
    }
}
