﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;

namespace Ndihmo.DataModels
{
   public  class ApplicationUser : IdentityUser
    {
      
        [Required(ErrorMessage = "City is required")]
        public string CityId { get; set; }
        public virtual City City { get; set; }
        [Required(ErrorMessage = "Full Name Is Required")]
        public string FullName { get; set; }
        public DateTime JoinedDate { get; set; }
        public string ProfilePicPath { get; set; } = "DefaultAvatar.svg";


        public virtual List<Donation> Donations { get; set; } = new();
        public virtual List<ApproveRequest> ApprovedRequests { get; set; } = new();
        public virtual List<Campaign> Campaigns { get; set; } = new();
    }
}
