﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Ndihmo.DataModels
{
    public class Campaign :BaseModels
    {
        [Required(ErrorMessage = "A Title Is Required")]
        public string Title { get; set; }
        [Required(ErrorMessage = "A Description Is Required")]
        public string Description { get; set; }
        public DateTime StartDate { get; set; }
        [Required(ErrorMessage = "A Donation Goal Is Required")]
        public double CampaignGoal { get; set; }
        public string ImagePath { get; set; } = "Default.jpg";
        public string UserId { get; set; }
        public virtual ApplicationUser User { get; set; }
        [Required(ErrorMessage = "A City Is Required")]
        public string CityId { get; set; }
        public virtual City  City { get; set; }
        [Required(ErrorMessage = "A Category Is Required")]
        public string CategoryId { get; set; }
        public virtual Category Category { get; set; }
        public virtual List<Update> CampaignUpdates{ get; set; }
        public virtual List<ApproveRequest> Requests { get; set; }
        public virtual List<Donation> Donations { get; set; }
    }

    
}
