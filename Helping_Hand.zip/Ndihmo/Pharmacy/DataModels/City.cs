﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace Ndihmo.DataModels
{
    public class City:BaseModels
    {

        public string Name { get; set; }
        public virtual List<ApplicationUser> Users { get; set; }
        public virtual List<Campaign> Campaigns { get; set; }

    }
}
