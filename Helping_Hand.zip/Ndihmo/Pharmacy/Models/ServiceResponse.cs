﻿namespace Pharmacy.Models
{
    public class ServiceResponse<T>
    {
        public string Message { get; set; }
        public bool Success { get; set; } = true;
        public T Data { get; set; }
    }
}