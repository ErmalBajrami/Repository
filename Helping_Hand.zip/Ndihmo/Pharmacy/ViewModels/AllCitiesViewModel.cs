﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Ndihmo.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using X.PagedList;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Metadata.Internal;


namespace Ndihmo.ViewModels
{
    public class AllCitiesViewModel
    {
        public string Name { get; set; }
        public IEnumerable<City> AllCities { get; set; }
        public string CityId { get; set; }
        public string OrderBy { get; set; }
        public bool OrderByCity { get; set; }
        public string FilterString { get; set; }

    }
}
