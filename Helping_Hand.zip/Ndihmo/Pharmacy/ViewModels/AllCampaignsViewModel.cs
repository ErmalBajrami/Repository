﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.Rendering;
using Ndihmo.DataModels;
using X.PagedList;

namespace Ndihmo.ViewModels
{
    public class AllCampaignsViewModel:PagingBaseModel
    {
        public IPagedList<Campaign> AllCampaigns { get; set; }
        public List<SelectListItem> Cities { get; set; }
        public string CityId { get; set; }
        public List<Campaign> Campaigns { get; set; } = new();
        public List<SelectListItem> Categories { get; set; } = new();
        public string SearchString { get; set; }
        public string OrderBy { get; set; }
        public string Categorie { get; set; }



    }
}