﻿namespace Ndihmo.ViewModels
{
    public class PagingBaseModel
    {
        private int _page;
        public string OrderBy { get; set; }
        public bool OrderByDes { get; set; }
        public string FilterString { get; set; }

        public PagingBaseModel()
        {
            
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="filterString"></param>
        /// <param name="orderBy"></param>
        /// <param name="orderByDes"></param>
        /// <param name="page"></param>
        public PagingBaseModel(string filterString,string orderBy,bool orderByDes, int page)
        {
            FilterString = filterString;
            OrderBy = orderBy;
            OrderByDes = orderByDes;
            Page = page;

        }

        public int Page
        {
            get =>_page ;
            set
            {
                if (value == 0)
                {
                    _page = 1;
                    return;
                }

                _page = value;
            }
        }
    }
}