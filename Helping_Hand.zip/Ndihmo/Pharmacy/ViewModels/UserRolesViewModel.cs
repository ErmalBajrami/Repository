﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Identity;
using Ndihmo.DataModels;

namespace Ndihmo.ViewModels
{
    public class UserRolesViewModel
    {
        public class UserRoleDto
        {
            public string RoleId { get; set; }
            public bool IsSelected { get; set; }
            public string RoleName { get; set; }
        }

        public ApplicationUser User { get; set; }
        public List<IdentityRole> AllRoles { get; set; }
        public List<UserRoleDto> UserRoles { get; set; } = new();
        public string UserId { get; set; }

        public List<IdentityRole> GetAllUserRolesFromDto()
        {
            List<IdentityRole> roles = new();
            foreach (var userRoleDto in UserRoles)
            {
                if (userRoleDto.IsSelected)
                {
                    roles.Add(new IdentityRole(){Id = userRoleDto.RoleId});
                } 
            }

            return roles;
        }
        public void GenerateUserRoleDto(List<IdentityRole> currentUseRole,List<IdentityRole> roleList)
        {
            foreach (var identityRole in roleList)
            {
                if (currentUseRole!=null&&currentUseRole.Any(x => x.Id == identityRole.Id))
                {
                    UserRoles.Add(new UserRoleDto(){RoleId = identityRole.Id,RoleName = identityRole.Name,IsSelected = true});
                }
                else
                {
                    UserRoles.Add(new UserRoleDto(){RoleId = identityRole.Id,RoleName = identityRole.Name,IsSelected = false});

                }
            }
        }
    }
    
}