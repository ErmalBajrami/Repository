﻿using System.Collections.Generic;
using Ndihmo.DataModels;

namespace Ndihmo.ViewModels
{
    public class HomePageModelViewModel
    {
        public List<Campaign> Campaigns { get; set; } = new();
    }
}