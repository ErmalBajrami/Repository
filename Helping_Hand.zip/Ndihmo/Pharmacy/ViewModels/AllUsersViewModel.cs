﻿using System.Collections.Generic;
using Ndihmo.DataModels;
using X.PagedList;

namespace Ndihmo.ViewModels
{
    public class AllUsersViewModel:PagingBaseModel
    {
      
        public string CityId { get; set; }
        public List<City> Cities { get; set; } = new();
        public IPagedList<ApplicationUser> AllUsers { get; set; }
    }
}