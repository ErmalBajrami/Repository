﻿using Microsoft.AspNetCore.Identity;
using X.PagedList;

namespace Ndihmo.ViewModels
{
    public class AllRolesViewModel:PagingBaseModel
    {

        public IPagedList<IdentityRole> AllRoles { get; set; }
        public bool OrderByDesc { get; set; }
        public bool OrderByAsc { get; set; }
        public string FilterString { get; set; }
       
        
    }
    
}