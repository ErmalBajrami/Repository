﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Rendering;
using Ndihmo.DataModels;

namespace Ndihmo.ViewModels
{
    public class CampaignsViewModel
    {
        public List<SelectListItem> CampaignCategory { get; set; }
        public Campaign Campaign { get; set; }
        public IFormFile FormFile { get; set; }
        public List<SelectListItem> Cities { get; set; }
    }
}